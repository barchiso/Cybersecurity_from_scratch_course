import os
import sqlite3
import subprocess
from urllib.parse import quote

from flask import Flask, request, render_template, redirect, session, url_for, send_from_directory, abort

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "dev-secret-change-me")

DB = "shop.db"
MODE = os.getenv("MODE", "vuln")  # vuln | fixed

if not os.path.exists(DB):
    import init_db  # noqa: F401


def query_all(q: str):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute(q)
    rows = c.fetchall()
    conn.close()
    return rows


def query_one_param(sql: str, params: tuple):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute(sql, params)
    row = c.fetchone()
    conn.close()
    return row


def is_logged_in() -> bool:
    return session.get("logged_in") is True


def login_required(fn):
    def wrapper(*args, **kwargs):
        if not is_logged_in():
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)

    wrapper.__name__ = fn.__name__
    return wrapper


@app.route("/")
def index():
    # 🔒 Приховані товари не показуються
    products = query_all("SELECT * FROM products WHERE is_hidden = 0")
    return render_template("index.html", products=products)


@app.route("/product")
def product():
    pid = request.args.get("id", "1")

    # Спеціально залишаємо без фільтра is_hidden
    # щоб прихований товар можна було знайти напряму по ID
    if MODE == "vuln":
        rows = query_all(f"SELECT * FROM products WHERE id = {pid}")
        if not rows:
            return "Product not found", 404
        product_data = rows[0]
    else:
        product_data = query_one_param("SELECT * FROM products WHERE id = ?", (pid,))
        if not product_data:
            return "Product not found", 404

    last_name = request.args.get("name", "")
    last_comment = request.args.get("comment", "")

    return render_template(
        "product.html",
        product=product_data,
        last_name=last_name,
        last_comment=last_comment,
        mode=MODE,
    )


@app.route("/review", methods=["POST"])
def review():
    pid = request.form.get("product_id", "1")
    name = request.form.get("name", "")
    comment = request.form.get("comment", "")
    return redirect(f"/product?id={quote(str(pid))}&name={quote(name)}&comment={quote(comment)}")


@app.route("/search")
def search():
    q = request.args.get("q", "")

    # 🔒 Приховані товари виключені з пошуку
    if MODE == "vuln":
        products = query_all(f"SELECT * FROM products WHERE is_hidden = 0 AND name LIKE '%{q}%'")
    else:
        conn = sqlite3.connect(DB)
        c = conn.cursor()
        c.execute(
            "SELECT * FROM products WHERE is_hidden = 0 AND name LIKE ?",
            (f"%{q}%",)
        )
        products = c.fetchall()
        conn.close()

    return render_template("search.html", products=products)


@app.route("/login", methods=["GET", "POST"])
def login():
    next_path = request.args.get("next", "/admin")

    if request.method == "GET":
        return render_template("login.html", error=None, next=next_path)

    username = request.form.get("username", "")
    password = request.form.get("password", "")

    import base64
    password_b64 = base64.b64encode(password.encode("utf-8")).decode("utf-8")

    row = query_one_param(
        "SELECT id FROM users WHERE username = ? AND password_b64 = ?",
        (username, password_b64),
    )

    if row:
        session["logged_in"] = True
        session["username"] = username
        return redirect(next_path)

    return render_template("login.html", error="Invalid credentials", next=next_path)


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


@app.route("/admin")
@login_required
def admin():
    return render_template("admin.html")


@app.route("/admin/diagnostics")
@login_required
def diagnostics():
    target = request.args.get("target", "localhost")

    if MODE == "vuln":
        cmd = f"ping -c 1 {target}"
        output = subprocess.getoutput(cmd)
    else:
        output = "Diagnostics disabled in fixed mode."

    return f"<pre>{output}</pre>"


@app.route("/robots.txt")
def robots():
    if MODE != "vuln":
        return "User-agent: *\nDisallow:\n", 200, {"Content-Type": "text/plain; charset=utf-8"}

    data = """User-agent: *
Disallow: /backup/

# FLAG{ROBOTS_DISCOVERED}
"""
    return data, 200, {"Content-Type": "text/plain; charset=utf-8"}


@app.route("/backup", strict_slashes=False)
@app.route("/backup/", strict_slashes=False)
def backup_index():
    if MODE != "vuln":
        abort(404)
    return "OK", 200


@app.route("/backup/<path:filename>")
def backup_files(filename):
    if MODE != "vuln":
        abort(404)

    base_dir = os.path.join(app.root_path, "backup")
    return send_from_directory(base_dir, filename)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)