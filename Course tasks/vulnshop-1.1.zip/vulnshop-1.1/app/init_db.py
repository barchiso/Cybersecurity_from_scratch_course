import sqlite3

conn = sqlite3.connect("shop.db")
c = conn.cursor()

# Core tables
c.execute("""
CREATE TABLE products (
  id INTEGER PRIMARY KEY,
  name TEXT,
  description TEXT,
  price INTEGER,
  is_hidden INTEGER NOT NULL DEFAULT 0
)
""")

c.execute("CREATE TABLE reviews (id INTEGER PRIMARY KEY, product_id INTEGER, name TEXT, comment TEXT)")

# Auth tables (training)
c.execute("""
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_b64 TEXT NOT NULL
)
""")

c.execute("""
CREATE TABLE training_secrets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  value_b64 TEXT NOT NULL
)
""")

products = [
    (1, "Laptop", "Powerful business laptop", 1200, 0),
    (2, "Phone", "Secure smartphone", 800, 0),
    (3, "Router", "Enterprise router", 400, 0),

    # Hidden “confidential” product (not shown on index/search if you filter by is_hidden=0)
    (333, "Internal Vault Token", "CONFIDENTIAL: FLAG{HIDDEN_PRODUCT_333}", 9999, 1),
]
c.executemany("INSERT INTO products VALUES (?, ?, ?, ?, ?)", products)

# Admin credentials for the lab (base64 is NOT secure, it's intentionally weak for training)
admin_user = "admin"
admin_pass_b64 = "U3RyMG5nR1Bhc3M0"  # base64("Str0ngGPass4")
c.execute("INSERT INTO users (username, password_b64) VALUES (?, ?)", (admin_user, admin_pass_b64))

# Optional: a separate “hint” record students can discover as part of the training story
c.execute(
    "INSERT INTO training_secrets (name, value_b64) VALUES (?, ?)",
    ("admin_password_b64", admin_pass_b64)
)

conn.commit()
conn.close()